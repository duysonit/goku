local re = require 're'
local lpeg = require 'lpeg'
local match = lpeg.match
-- best trim function
function trim(s)
    local ptrim = re.compile("%s* {(%s* %S+)*}")
    return match(ptrim, s)
end


local s = "                                                                                        con co be                                                             "
print(trim(s))
