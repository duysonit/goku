import requests

URL = "http://waf.nxquang.com?id="
def checkPattern(pattern):
    r = requests.get(URL + pattern)
    if r.status_code == 400:
        return False
    return True

f = open('patterns/XSS.txt')
o = open('result.txt', 'w')
i = 0
c = 0
for pattern in f:
    pattern = pattern.strip()
    if checkPattern(pattern):
        o.write(pattern + " => Pass\n")
        print pattern + " => Pass"
    else:
        o.write(pattern + " => Block\n")
        print pattern + " => Block"
        c+= 1
    i += 1
o.close()
f.close()
print "Block: ", c,"/", i